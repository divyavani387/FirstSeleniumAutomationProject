package automationDemo;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

//Author: Divyavani K
//Project: Selenium Login Automation Demo
//Description: Automates login functionality on a demo site and validates the result.


public class LoginTest {

	public static void main(String[] args) {
		
		
		// Set up the ChromeDriver
		
		WebDriver driver=new ChromeDriver();
					
		// Open the demo login page and maximizing it
		
		driver.get("https://the-internet.herokuapp.com/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		// Enter username and password
		
		WebElement username = driver.findElement(By.xpath("//input[@name='username']"));
		username.sendKeys("tomsmith");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		WebElement password = driver.findElement(By.xpath("//input[@id='password']"));
		password.sendKeys("SuperSecretPassword!");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		// Click the login button
		
		WebElement loginbutton = driver.findElement(By.xpath("//button[@type='submit']"));
		loginbutton.click();
		
		// Validate login success
		
		WebElement message = driver.findElement(By.id("flash"));
        if (message.getText().contains("You logged into a secure area!")) {
           System.out.println("✅ Login test passed!");
        } else {
           System.out.println("❌ Login test failed!");
        }
		
        // Close browser
        
        driver.quit();

	}

}
